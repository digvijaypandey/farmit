(function(app){    
	

	$(document).ready(function(){
			

	
	});
	

})(Player = Player || {})
var Player;